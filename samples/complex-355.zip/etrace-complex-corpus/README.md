# E-TRACE complex realistic corpus: Halcyon Freight IR-2026-014/015

355 email files (plus one duplicate acquisition) from 11 collected mailboxes at a fictional
Singapore freight company, 2 to 23 October 2026. The files come from ten staff custodians plus the
SOC shared mailbox, and include Inbox, Sent Items and Deleted Items.

Three weeks of ordinary business mail surround a four-stage attack. Every internal message
appears once per collected mailbox that holds it, as it would in a real multi-custodian
collection.

Everything is fictional. Domains use `.example` and public IPs come from the RFC 5737
documentation ranges. The attachments are inert, and the QR codes point at a reserved domain.

## The incident (answer key; spoilers)

| Phase | When | What happened |
| --- | --- | --- |
| P1 | 7 Oct 10:02-12:40 | Credential-phish "file share" lure sent to 8 staff over 2.5 hours from two sending IPs (198.51.100.77, then .78) and two sender domains. Safe Links rewrites the link for the six finance and procurement mailboxes, so only three copies show the literal URL. |
| P2 | 7 Oct 16:31-17:20 | Priya's password is used from 198.51.100.77 (OWA, so the X-Originating-IP header is present). A Bcc blast goes out from her real mailbox with a shortened link to a lookalike payroll portal. There are two NDRs for departed staff and an out-of-office reply. Siti asks whether it is legitimate, and the attacker replies to her as Priya. The SOC alert follows at 17:48. |
| P3 | 8-16 Oct | Supplier thread hijack (business email compromise). The attacker replies inside the genuine Meridian invoice thread from Meridian's real, compromised mailbox (SPF/DKIM/DMARC pass, sign-in IP 198.51.100.79) and sets Reply-To to the lookalike domain `meridian-rnarine.example`. The "signed" bank-change letter comes from the lookalike. Finance approves, and the 16 Oct payment run pays the attacker. |
| Discovery | 20 Oct | The real supplier asks why their payment went to an account that isn't theirs, and the SOC opens IR-2026-015. |
| P4 | 19 Oct 08:12-14:31 | QR-code "salary adjustment" PDFs, one unique PDF per recipient with personalised subjects, from five rotating sender domains and IPs over six hours. There is no URL anywhere in the email bodies. |

Attacker-authored files (34):

| Phase | File |
| --- | --- |
| P1 | `2026-10-07_1002_priya-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1009_siti-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1021_benjamin-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1048_marcus-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1117_daniel-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1155_aisyah-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1231_grace-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P1 | `2026-10-07_1240_chloe-inbox_aaron-chua-shared-statement-of-account-q3-2026-w.eml` |
| P2 | `2026-10-07_1642_aisyah-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_benjamin-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_chloe-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_daniel-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_grace-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_jasmine-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_marcus-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_michael-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_priya-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_priya-sent_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1642_siti-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1703_priya-sent_payroll-portal-migration-verify-your-details-by-.eml` |
| P2 | `2026-10-07_1703_siti-inbox_payroll-portal-migration-verify-your-details-by-.eml` |
| P3 | `2026-10-08_0910_benjamin-inbox_invoice-inv-2026-10391-from-meridian-marine-supp.eml` |
| P3 | `2026-10-08_0910_priya-inbox_invoice-inv-2026-10391-from-meridian-marine-supp.eml` |
| P3 | `2026-10-08_1320_benjamin-inbox_invoice-inv-2026-10391-from-meridian-marine-supp.eml` |
| P3 | `2026-10-08_1320_priya-inbox_invoice-inv-2026-10391-from-meridian-marine-supp.eml` |
| P4 | `2026-10-19_0812_benjamin-inbox_q4-salary-adjustment-benjamin-ng.eml` |
| P4 | `2026-10-19_0847_priya-inbox_q4-salary-adjustment-priya-raman.eml` |
| P4 | `2026-10-19_0930_siti-inbox_q4-salary-adjustment-siti-nurhaliza-binte-ahmad.eml` |
| P4 | `2026-10-19_1041_marcus-inbox_q4-salary-adjustment-marcus-lim.eml` |
| P4 | `2026-10-19_1105_grace-inbox_q4-salary-adjustment-grace-lim.eml` |
| P4 | `2026-10-19_1218_daniel-inbox_q4-salary-adjustment-daniel-koh.eml` |
| P4 | `2026-10-19_1302_chloe-inbox_q4-salary-adjustment-chloe-lee.eml` |
| P4 | `2026-10-19_1427_michael-inbox_q4-salary-adjustment-michael-tan.eml` |
| P4 | `2026-10-19_1431_aisyah-inbox_q4-salary-adjustment-nur-aisyah-rahim.eml` |

## Realistic difficulties built in

- **Multi-mailbox duplicates.** The same message appears in the sender's Sent Items and in every
  collected recipient's Inbox, with the same Message-ID. Only the delivery headers differ.
- **Safe Links rewriting.** Inbound external links in the six pilot mailboxes are rewritten with
  per-recipient tokens. HTML link text that shows the original URL stays visible.
- **Benign mass mail.**
  - A newsletter goes to five subscribers each week.
  - An authorised phishing simulation by IT reaches all custodians with an identical subject.
  - Payslip notifications, all-staff Bcc announcements, and a calendar invite with an .ics file.
- **Signatures.** Outlook embeds the company-logo PNG and the website link in roughly every staff
  email. Quoted images are re-embedded in Outlook replies but not in iPhone or plain-text replies.
- **Other languages and charsets.** A Japanese customer (ISO-2022-JP, Thunderbird), a Chinese
  supplier (GB2312, Foxmail) and a Malaysian haulier (Malay).
- **A London traveller and a scanner.** The traveller's emails cross the BST to GMT change. Scan-to-email
  messages have a Date header with no time zone.
- **List mail and quoting.** A mailing list received by two custodians, with a References-only
  reply. There are iPhone, Outlook, Thunderbird and plain-text quoting styles.
- **Message wrappers.** Reports to the SOC are forwarded inline and as attachments (message/rfc822).
  Bounces are real multipart/report NDRs.
- **Duplicate acquisition.** Priya's Deleted Items copy of the blast is byte-identical to her
  Sent Items copy, and is declared as a duplicate acquisition.

## Folders

| Folder | Purpose |
| --- | --- |
| `conformance/` | Labels show what each documented rule *should* output. A correct implementation scores 1.0 with exit code 0. |
| `intent/` | The same bytes, labelled with the investigator's questions. `url_reuse` means the same destination after unwrapping Safe Links and resolving the short link. `possible_coordination` means pairs within one attacker distribution wave (P1, P2 or P4). Expect exit code 1. |
| `results/` | My evaluate.py output (E-TRACE 1.0.0, default parameters). |
| `build_complex_corpus.py` | Regenerates the corpus byte-for-byte. Labels come from what each scenario writes, never from E-TRACE. |

## How to run (PowerShell)

```powershell
cd "C:\Users\lewta\Desktop\ICT3215 Digital Forensics\Project\Digital-Forensics"
C:\Users\lewta\etrace-venv\Scripts\Activate.ps1
$X = "C:\Users\lewta\Desktop\ICT3215 Digital Forensics\etrace-complex-corpus"
python evaluation\evaluate.py "$X\conformance" --output "$X\..\complex-conformance-results.json"
python evaluation\evaluate.py "$X\intent" --output "$X\..\complex-intent-results.json"
etrace init "$X\..\complex.db" --name "Halcyon Freight IR-2026-014/015"
etrace ingest "$X\..\complex.db" "$X\conformance"
etrace analyze "$X\..\complex.db"
etrace serve "$X\..\complex.db" --port 8765
```

## Results from my run

| Rule | Conformance P / R | Intent P / R |
| --- | --- | --- |
| attachment_reuse (20,491 pairs) | 1.00 / 1.00 | 1.00 / 1.00 |
| url_reuse | 1.00 / 1.00 (34,746) | **1.00 / 0.94** (37,073 destination pairs; 2,327 missed) |
| reply | 1.00 / 1.00 (13 edges) | 1.00 / 1.00 |
| possible_coordination | 1.00 / 1.00 (1,328) | **0.05 / 0.55** (65 TP, 1,263 FP, 54 FN) |

The single-payload baseline scores 0.04 / 0.46 on the coordination intent target.

### What the realistic data exposes

1. **Duplicate Message-IDs break reply reconstruction.** 168 files carry In-Reply-To or References
   headers, but only 13 reply edges can be resolved. The engine reports 155 `ambiguous_parent`
   diagnostics because nearly every parent exists as a Sent copy plus one or more Inbox copies.
   That includes the attacker-as-Priya reply chain in P2 and most of the P3 hijack thread. The
   behaviour is documented and conservative, but in a multi-custodian case it hides almost every
   conversation. Grouping files by Message-ID before resolving parents would recover them.
2. **The coordination heuristic is dominated by signatures and copies.** 1,328 hypotheses are
   raised and about 95% are benign:
   - copies of the same internal email
   - colleagues whose emails share the logo PNG and website link
   - newsletters, the phishing simulation and payslip notices

   The logo appears in 202 files and the website link in 264, so they also dominate the
   attachment-reuse and URL-reuse groups. Suppressing inline signature images and the
   organisation's own domain would remove most of this noise.
3. **Real evasions defeat exact matching.**
   - Safe Links tokens hide shared URLs in the pilot mailboxes.
   - The short link and personalised URLs never match.
   - P4's unique PDFs, personalised subjects and rotating senders produce zero detections.
   - The cross-wave link (all phases use 198.51.100.77-.79) is outside the 3,600 s window.
4. **The hijack is invisible to coordination by design.** P3 sits inside a reply thread, and its
   strongest signal (a known supplier domain suddenly sending from 198.51.100.79 with a lookalike
   Reply-To) is not one of the four rules.

These findings are a fair basis for a limitations or future-work section. The engine itself
behaved exactly as specified on all 355 files.
