# E-TRACE realistic test corpus: Halcyon Freight invoice-phishing incident

41 email files collected from seven mailboxes (Inbox, Sent Items, Drafts and a SOC shared
mailbox) at a fictional Singapore logistics company, 12 to 15 October 2026. Mixed in with
ordinary business mail is a lookalike-supplier invoice phishing campaign sent in two waves.
The scenario is written to be read as an investigation, not only to be scored.

Everything here is fictional. All domains use the reserved `.example` TLD and all public IPs
come from the RFC 5737 documentation ranges, so no real person, company or host is involved
and nothing in the files can reach the internet. The phishing "login page" attachment is
inert HTML.

## What makes these more realistic than the generator tiers

- Transport headers look real: three- and four-hop Received chains (Postfix MX into an Exchange-style
  mailbox server), Authentication-Results, DKIM-Signature, Reply-To, X-Mailer/User-Agent,
  Thread-Index, List-Id/List-Unsubscribe and Auto-Submitted.
- Mail comes from several clients: Outlook HTML with signatures and an inline logo, iPhone plain text,
  Thunderbird, a Mailman list, an ESP newsletter, a PHPMailer phishing kit and an IT-ticket system.
- The bodies are multipart/alternative, quoted-printable and base64, with quoted reply history,
  Outlook "From/Sent/To" quote blocks, and ISO-2022-JP Japanese.
- The attachments are real files: a PDF invoice, a PDF policy, two XLSX spreadsheets, an .ics invite,
  the HTML lure, and a ZIP containing the lure.
- The tricky parts come from real investigations:
  - The lookalike domains pass SPF, DKIM and DMARC.
  - One lure link has an upper-case host, and one is personalised.
  - The same payload arrives under several filenames.
  - Some copies were forwarded as an attachment (message/rfc822) and others inline.
  - The IT security alert defangs its indicators.
  - One wave-2 message has a fake "RE:" and a fabricated In-Reply-To.
  - One Date header is skewed, and one MIME structure is malformed.
  - There is an unsent draft with no Date.
  - The HR notice has the same Message-ID in two mailboxes, so a reply to it has an ambiguous parent.
  - One list reply uses References only, and another replies to a message that was never collected.
  - An out-of-office auto-reply goes to the attacker.
  - A plain-text URL ends with a full stop.
  - A separate phish arrives from the same hosting IP hours later.

## Folders

| Folder | Purpose |
| --- | --- |
| `conformance/` | Evidence plus `ground_truth.json` = what each rule *should* output according to its definition. Benign matches (newsletter copies, signature logos, forwards) count as positives because the rule covers them. A correct implementation scores 1.0 with exit code 0. |
| `intent/` | Byte-identical evidence. `possible_coordination` is relabelled to the investigator's real question: "which pairs belong to the attacker's planned distribution?" The other rules are unchanged. Expect exit code 1. This variant measures the heuristic, not the code. |
| `results/` | evaluate.py output from my run (E-TRACE 1.0.0, default parameters). |
| `build_realistic_corpus.py` | Regenerates the corpus byte-for-byte. Ground truth comes from what each scenario writes into each message, never from E-TRACE's parser or engine. |

## How to run

```powershell
python evaluation/evaluate.py <path>\conformance --output <out>\conformance-results.json
python evaluation/evaluate.py <path>\intent      --output <out>\intent-results.json

etrace init  <case>.db --name "Halcyon Freight phishing"
etrace ingest <case>.db <path>\conformance
etrace analyze <case>.db
etrace serve <case>.db
```

## Results from my run

| Rule | Conformance P / R | Intent P / R |
| --- | --- | --- |
| attachment_reuse (114 pairs) | 1.00 / 1.00 | same |
| url_reuse (202 pairs) | 1.00 / 1.00 | same |
| reply (13 directed edges) | 1.00 / 1.00 | same |
| possible_coordination | 1.00 / 1.00 (33 pairs) | **0.27 / 0.43** (9 TP, 24 FP, 12 FN) |

The single-payload baseline scores 0.18 / 0.43 on the intent target, so the two-category rule
is better than that naive baseline. Where the heuristic goes wrong:

- **False alarms (24).** The three newsletter copies are flagged. So are the two HR notice copies
  and the reply to them, and the internal responders: the victim's reply, the forwards to the SOC,
  the SOC alert and the follow-ups. The responders are paired with each other because Outlook embeds
  the same company-logo PNG and website link in every signature. That logo alone produces about
  90 of the 114 attachment-reuse pairs.
- **Misses (12).** Wave 1 and wave 2 are about 23 hours apart, which is outside the 3,600 s window.
  The ZIP-wrapped wave-2 copy shares no hash with wave 1.

Diagnostics you should see:

- `ambiguous_parent` on the HR reply.
- `missing_parent` on the fabricated wave-2 In-Reply-To and on the list reply to an uncollected message.
- `references_fallback` on the list reply that has References only.

Warnings you should see: `missing_date` (draft), `date_after_received` (skewed wave-2 copy),
`embedded_message` (forward-as-attachment), `unsupported_text_part` (calendar body) and
`CloseBoundaryNotFoundDefect` (malformed wave-2 copy).

## Message guide

### Internal Q4 warehouse planning thread (Outlook + iPhone replies)

- `daniel-inbox_2026-10-12_re-q4-shipment-schedule-2.eml` (Daniel Koh / Inbox, 2026-10-12 15:05): -
- `daniel-inbox_2026-10-12_re-q4-shipment-schedule.eml` (Daniel Koh / Inbox, 2026-10-12 14:47): iOS plain-text reply; quotes the SharePoint link from the parent's text part.
- `marcus-inbox_2026-10-12_re-q4-shipment-schedule-3.eml` (Marcus Lim / Inbox, 2026-10-12 15:31): -
- `weijie-inbox_2026-10-12_q4-shipment-schedule.eml` (Ong Wei Jie / Inbox, 2026-10-12 14:20): -

### Customer thread with Japanese client (ISO-2022-JP, plain-text URL punctuation)

- `daniel-inbox_2026-10-13_container-status-hflu4471023.eml` (Daniel Koh / Inbox, 2026-10-13 10:15): Subject, From and body are ISO-2022-JP; oldest Received names two IPs, so no single origin IP.
- `daniel-inbox_2026-10-13_re-container-status-hflu4471023.eml` (Daniel Koh / Inbox, 2026-10-13 11:02): HTML part auto-links the tracking URL without the full stop; text part keeps it.
- `daniel-sent_2026-10-13_re-container-status-hflu4471023.eml` (Daniel Koh / Sent Items, 2026-10-13 09:40): Plain-text only. 'Tracking: <url>.' - the full stop is captured as part of the URL, a documented limitation; it will NOT match the clean link in other messages.

### Vendor newsletter in three mailboxes (benign bulk mail; expected coordination false alarm)

- `daniel-inbox_2026-10-13_portlink-weekly-wk41.eml` (Daniel Koh / Inbox, 2026-10-13 06:30): Per-recipient unsubscribe link and tracking pixel; article links are identical.
- `marcus-inbox_2026-10-13_portlink-weekly-wk41.eml` (Marcus Lim / Inbox, 2026-10-13 06:30): Per-recipient unsubscribe link and tracking pixel; article links are identical.
- `priya-inbox_2026-10-13_portlink-weekly-wk41.eml` (Priya Raman / Inbox, 2026-10-13 06:30): Per-recipient unsubscribe link and tracking pixel; article links are identical.

### Routine unrelated traffic on incident day

- `daniel-inbox_2026-10-14_forklift-4-maintenance.eml` (Daniel Koh / Inbox, 2026-10-14 09:20): -
- `daniel-inbox_2026-10-14_it-ticket-20931-resolved.eml` (Daniel Koh / Inbox, 2026-10-14 08:47): -
- `marcus-inbox_2026-10-14_quotation-q-55821.eml` (Marcus Lim / Inbox, 2026-10-14 10:10): -
- `siti-inbox_2026-10-14_parcel-out-for-delivery.eml` (Siti Nurhaliza binte Ahmad / Inbox, 2026-10-14 08:15): -

### Phishing wave 1: lookalike-supplier invoice lure (attacker-sent)

- `daniel-inbox_2026-10-14_overdue-invoice-inv-2026-10482.eml` (Daniel Koh / Inbox, 2026-10-14 01:36): Personalised link (&r=...) and different sending IP; shares attachment and subject only.
- `marcus-inbox_2026-10-14_overdue-invoice-inv-2026-10482.eml` (Marcus Lim / Inbox, 2026-10-14 01:21): Same attachment bytes under a different filename; second lookalike domain (rn vs m).
- `priya-inbox_2026-10-14_overdue-invoice-inv-2026-10482.eml` (Priya Raman / Inbox, 2026-10-14 01:12): Lookalike domain passes SPF/DKIM/DMARC - authentication is not legitimacy.
- `siti-inbox_2026-10-14_overdue-invoice-inv-2026-10482.eml` (Siti Nurhaliza binte Ahmad / Inbox, 2026-10-14 01:14): Link host written in upper case; must normalise to the same URL as the other copies. Subject is base64-encoded UTF-8 (others quoted-printable); decodes identically.

### Victim and responder activity around wave 1

- `jasmine-inbox_2026-10-14_fwd-overdue-invoice-inline.eml` (Jasmine Tan / Inbox, 2026-10-14 10:07): Inline forward: re-attaches the identical HTML file and carries the lure URL.
- `marcus-inbox_2026-10-14_re-fwd-overdue-invoice.eml` (Marcus Lim / Inbox, 2026-10-14 10:40): -
- `marcus-sent_2026-10-14_automatic-reply-overdue-invoice.eml` (Marcus Lim / Sent Items, 2026-10-14 09:21): Out-of-office auto-reply to the attacker; 'Automatic reply:' prefix is not stripped.
- `priya-drafts_re-overdue-invoice-inv-2026-10482.eml` (Priya Raman / Drafts, no Date): Unsent draft: no Date and no Received headers, so no time is known.
- `priya-sent_2026-10-14_re-overdue-invoice-inv-2026-10482.eml` (Priya Raman / Sent Items, 2026-10-14 09:48): Victim replied to the attacker's Reply-To address (credential entry implied).
- `siti-inbox_2026-10-14_security-alert-meridian-phishing.eml` (Siti Nurhaliza binte Ahmad / Inbox, 2026-10-14 10:31): IOCs are defanged (hxxps, [.]) so they must NOT match the live lure URL.
- `soc-inbox_2026-10-14_fw-overdue-invoice-as-attachment.eml` (SOC shared mailbox / Inbox, 2026-10-14 09:58): Forward-as-attachment (message/rfc822): the inner email's URL and HTML attachment are NOT attributed to this message.

### Industry mailing list (Mailman): References-only reply and reply to an uncollected message

- `marcus-inbox_2026-10-13_re-sg-freight-reefer-plugs.eml` (Marcus Lim / Inbox, 2026-10-13 10:12): Parent message was never collected -> missing_parent diagnostic, no reply edge.
- `marcus-inbox_2026-10-13_re-sg-freight-tuas-gate3-2.eml` (Marcus Lim / Inbox, 2026-10-13 09:30): -
- `marcus-inbox_2026-10-13_re-sg-freight-tuas-gate3.eml` (Marcus Lim / Inbox, 2026-10-13 08:47): References header only (no In-Reply-To) -> reply edge via References fallback.
- `marcus-inbox_2026-10-13_sg-freight-tuas-gate3.eml` (Marcus Lim / Inbox, 2026-10-13 08:05): Oldest Received from-clause holds two IPs -> no origin IP.

### Legitimate supplier invoice thread (real Meridian Marine domain)

- `priya-inbox_2026-10-12_invoice-inv-2026-10391.eml` (Priya Raman / Inbox, 2026-10-12 10:03): -
- `priya-inbox_2026-10-14_re-query-inv-2026-10482.eml` (Priya Raman / Inbox, 2026-10-14 11:32): Real supplier's Outlook signature logo is the same image as in INV-2026-10391.
- `priya-sent_2026-10-12_re-invoice-inv-2026-10391.eml` (Priya Raman / Sent Items, 2026-10-12 10:26): Sent Items copy: no Received headers, so no origin IP and no received time.
- `priya-sent_2026-10-14_query-inv-2026-10482.eml` (Priya Raman / Sent Items, 2026-10-14 11:05): -

### All-staff HR notice collected from two mailboxes (duplicate Message-ID) and a reply to it

- `priya-inbox_2026-10-13_travel-expense-policy.eml` (Priya Raman / Inbox, 2026-10-13 11:00): Same Message-ID as the other mailbox copy; bytes differ only in delivery headers.
- `siti-inbox_2026-10-13_travel-expense-policy.eml` (Siti Nurhaliza binte Ahmad / Inbox, 2026-10-13 11:00): Same Message-ID as the other mailbox copy; bytes differ only in delivery headers.
- `siti-sent_2026-10-13_re-travel-expense-policy.eml` (Siti Nurhaliza binte Ahmad / Sent Items, 2026-10-13 11:41): In-Reply-To matches two collected messages -> ambiguous_parent, no reply edge.

### Phishing wave 2: 'FINAL NOTICE' follow-up with new link (attacker-sent)

- `priya-inbox_2026-10-15_final-notice-inv-2026-10482.eml` (Priya Raman / Inbox, 2026-10-15 00:52): Fabricated In-Reply-To pointing at a message that never existed -> missing_parent. Fake 'RE:' prefix; normalised subject still differs from wave 1 ('FINAL NOTICE').
- `siti-inbox_2026-10-15_final-notice-inv-2026-10482.eml` (Siti Nurhaliza binte Ahmad / Inbox, 2026-10-15 00:55): Date header is ~12 min later than the server receipt time (forged/skewed clock).
- `weijie-inbox_2026-10-15_final-notice-inv-2026-10482.eml` (Ong Wei Jie / Inbox, 2026-10-15 01:03): HTML lure inside a ZIP (different hash); final MIME boundary missing (malformed).

### Calendar invite (text/calendar body part and .ics attachment)

- `weijie-inbox_2026-10-13_phishing-awareness-refresher.eml` (Ong Wei Jie / Inbox, 2026-10-13 16:02): Unnamed text/calendar alternative is retained but not searched (unsupported_text_part).

### Separate credential phish from the same hosting IP, hours later

- `weijie-inbox_2026-10-14_mailbox-almost-full.eml` (Ong Wei Jie / Inbox, 2026-10-14 13:15): Same origin IP as wave 1 but 4 hours later; shared IP alone is not a rule match.
